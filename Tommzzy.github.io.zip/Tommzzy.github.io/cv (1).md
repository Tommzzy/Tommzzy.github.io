---
layout: page
title: Curriculum Vitae
permalink: /cv/
---

# Curriculum Vitae

## Education
**Bachelor of Science in Software Engineering**  
United States International University - Africa  
*Sept 2021 – Sept 2025*

**High School Certificate**  
Sunshine Secondary School  
*Jan 2017 – Apr 2021*

## Skills
- Software Development
- Technical Proficiency
- Problem Solving
- Collaborative Leadership
- Adaptability
- Attention to Detail
- User-Centered Design

## Community Service
**Happy Life Children’s Home – Volunteer**  
*May 2024 – July 2024*  
Dedicated over 80 hours providing care and support to children in Roysambu-Nairobi. Supported daily activities and educational programs in a nurturing environment.

## Referees
**Ryan Mbuthia**  
📧 ryan.mbuthia02@gmail.com  
📱 +254112011495  

**Lewis Mwangi**  
📧 gathaiyawis1122@gmail.com  
📱 +254702320995