---
layout: home
title: Thomas Duncan Richu
---

# Thomas Duncan Richu

Driven and enthusiastic individual with a strong foundation in Information Systems and Technology, specializing in Forensic Information Technology, Cybersecurity, and Programming. Passionate about solving real-world challenges and expanding expertise in the ever-evolving tech field.

📧 chiradans@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/in/thomas-chira-1b210824b/)  
📱 +254702634788